const axios = require('axios');
const md5 = require('md5'); 

exports.connDigiflazz = async (req, res) => {
    try {
        const response = await axios.post('https://api.digiflazz.com/v1/cek-saldo',{
            cmd : 'deposit',
            username : 'vapiseoE7dxW',
            sign : md5('vapiseoE7dxWe0549218-906c-57f3-9671-8f599e3bee9fdepo')
        });
        res.send(response.data);
        // const data = 'Api running normaly';
        // res.json(data);
    } catch (error) {
        console.log(error);
    }
}