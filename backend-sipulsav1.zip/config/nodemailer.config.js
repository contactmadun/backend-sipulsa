const nodemailer = require("nodemailer");

const user = process.env.USER;
const password  = process.env.PASSWORD;

const transport = nodemailer.createTransport({
    host: "mail.sipulsa.site",
    port: 465,
    secure: true,
    auth:{
        user: user,
        pass: password
    },
});

module.exports.sendConfirmationEmail = (name, email, confirmationCode) => {
    console.log('check');
    transport.sendMail({
        from: user,
        to: email,
        subject: "Konfirmasi Email Sipulsa",
        html: `<h1>Email Confirmation</h1>
            <h2>Hello ${name}</h2>
            <p>Terima kasih telah mendaftar di sipulsa. Untuk mengaktifkan akun silahkan klik link dibawah ini</p>
            <a href=https://sipulsa.site/confirm/${confirmationCode}> Click here</a>`
    }).catch(err => console.log(err));
}